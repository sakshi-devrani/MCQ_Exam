package com.example.exam;

public class Subj_Data_Model {

    String  subj;
    public Subj_Data_Model(String subj) {

        this.subj =subj;
    }
    public String getsubj(){return  subj ;}
}

